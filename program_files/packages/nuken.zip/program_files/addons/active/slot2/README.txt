Extract your add-on files here. The files should not be in a sub-folder; simply extract the files to this folder location.
This is slot 2, so it will appear below slot 1 in the add-on menu.